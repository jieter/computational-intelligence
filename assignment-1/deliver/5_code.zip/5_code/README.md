# TI2736-A Groep 5

Practicum van David Akkerman en Jan Pieter Waagmeester.

We hebben de opdracht redelijk afzonderlijk van elkaar uitgevoerd en dus twee afzonderlijk werkende programma's.

`main.m` roept een van de twee programma's aan.


## Notes

### Reading `.txt` files.
```
features = dlmread('data/features.txt');
targets = dlmread('data/targets.txt');

unknown = dlmread('data/unknown.txt');
```
